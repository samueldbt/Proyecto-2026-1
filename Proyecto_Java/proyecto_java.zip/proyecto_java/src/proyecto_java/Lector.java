package proyecto_java;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public final class Lector {
    private Lector(){
    }
    
    public static ArrayList<Materia> lectorMaterias(String filePath){
        ArrayList<Materia> materias = new ArrayList<>();
        String line;
        
        try(BufferedReader reader = new BufferedReader(new FileReader(filePath))){
            reader.readLine();
            while((line = reader.readLine())!= null){
                String [] parts = line.split(",");
                
                try{
                    if(parts.length>=11){
                        String nombre = parts[0].trim();
                        int codigo = Integer.parseInt(parts[1].trim());
                        String codigoG = parts[2].trim();
                        int capacidad = Integer.parseInt(parts[3].trim());
                        int matriculados = Integer.parseInt(parts[4].trim());
                        String profesor = parts[5].trim();
                        String dia = parts[6].trim();
                        int horaInicio = Integer.parseInt(parts[7].trim());
                        int horaFin = Integer.parseInt(parts[8].trim());
                        String edificio = parts[9].trim();
                        String salon = parts[10].trim();
                        Materia materiaActual = null;
                        for(Materia m: materias){
                            if(m.getCodigo() == codigo){
                                materiaActual = m;
                                break;
                            }
                        }
                        if(materiaActual == null){
                            materias.add(new Materia(nombre, codigo));
                        }else{
                        Grupo g = materiaActual.crearGrupo(codigoG, capacidad, matriculados, profesor);
                        g.crearHorario(dia, horaInicio, horaFin, edificio, salon);
                        }                        
                    }else{
                        System.out.println("Informacion incompleta para crear el objeto");
                    }
                }catch(Exception e){
                    System.out.println("Error creando el objeto: " + e.getMessage());
                }
            }
        }catch(IOException e){
            System.err.println("Error leyendo el archivo: " + e.getMessage());
        }
        return materias;
    }
}
