package proyecto_java;
import java.util.ArrayList;

public class Materia {
    private String nombre;
    private int codigo;
    private ArrayList<Grupo> grupos;
    
    public Materia(){
        this.nombre = "";
        this.codigo = -1;
        this.grupos = new ArrayList<>();
    }
    
    public Materia(String nombre, int codigo){
        setNombre(nombre);
        setCodigo(codigo);
        this.grupos = new ArrayList<>();
    }
    public Grupo crearGrupo(String codigoG, int capacidad, int matriculados, String profesor){
        Grupo g = new Grupo(codigoG, capacidad, matriculados, profesor);
        if(!grupos.contains(g)){
            grupos.add(g);
        }
        return g;
    }
    public ArrayList<Grupo> getGrupos(){
        return new ArrayList<>(grupos);
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public void setNombre(String nombre){
        Validacion.validarNombre(nombre);
        this.nombre = nombre;
    }
    
    public int getCodigo(){
        return codigo;
    }
    
    public void setCodigo(int codigo){
        Validacion.validarCodigoInt(codigo);
        this.codigo = codigo;
    }
    @Override
    public String toString() {
        return nombre + " (" + codigo + ")";
    }
}
