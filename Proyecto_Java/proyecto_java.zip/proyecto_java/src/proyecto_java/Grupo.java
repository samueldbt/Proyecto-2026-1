package proyecto_java;

import java.util.ArrayList;

public class Grupo{
    private String codigo;
    private int capacidad;
    private int matriculados;
    private String profesor;
    private ArrayList<Horario> horarios;
    
    public Grupo(){
        this.codigo = "";
        this.capacidad = 0;
        this.profesor = "";
        this.matriculados = 0;
        this.horarios = new ArrayList<>();
    }
    
    public Grupo(String codigo, int capacidad, int matriculados, String profesor) {
        setCodigo(codigo);
        setCapacidadyMatriculados(capacidad, matriculados);
        setProfesor(profesor);
        this.horarios = new ArrayList<>();
    }
    
    public void crearHorario(String dia, int horaInicio, int horaFin, String edificio, String salon){
        Horario h = new Horario(dia, horaInicio, horaFin, edificio, salon);
        if(!horarios.contains(h)){
            horarios.add(h);
        }
    }
    
    public ArrayList<Horario> getHorarios(){
        return new ArrayList<>(horarios);
    }
    
    public String getCodigo(){
        return codigo;
    }
    
    public void setCodigo(String codigo){
        Validacion.validarCodigoStr(codigo);
        this.codigo = codigo;
    }
    
    public int getCapacidad(){
        return capacidad;
    }
    
    public int getMatriculados(){
        return matriculados;
    }
    public void setCapacidadyMatriculados(int capacidad, int matriculados){
        Validacion.validarCapacidadyMatriculados(capacidad, matriculados);
        this.capacidad = capacidad;
        this.matriculados = matriculados;
    }
    
    public String getProfesor(){
        return profesor;
    }
    
    public void setProfesor(String profesor){
        Validacion.validarNombre(profesor);
        this.profesor = profesor;
    }
    
    @Override
    public String toString() {
        return "Grupo " + codigo + "-> Capacidad: " + capacidad + "-> Profesor: " + profesor;
    }
}
